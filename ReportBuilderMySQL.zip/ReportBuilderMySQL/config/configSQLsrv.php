<?php
$serverName = "haigp003\gp"; //serverName\instanceName

// Vu que UID et PWD ne sont pas spécifiés dans le tableau $connectionInfo,
// la connexion va tenter d'utiliser l'authentification Windows.
$connectionInfo = array( "Database"=>"HAITI", "UID"=>"DNaval", "PWD"=>"@27dmacd02");
$conn = sqlsrv_connect( $serverName, $connectionInfo);

if( $conn ) {
     //echo "Connexion etablie.<br />";
}else{
    // echo "La connexion n'a pu etre etablie.<br />";
     die( print_r( sqlsrv_errors(), true));
}
?>

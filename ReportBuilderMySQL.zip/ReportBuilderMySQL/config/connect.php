<?php
//Nom de la base de donn�es
$name_bd='test';

$link = mysql_connect('localhost','root','');
if (!$link) {
    die('Connexion impossible : ' . mysql_error());
}

mysql_select_db($name_bd);


?>